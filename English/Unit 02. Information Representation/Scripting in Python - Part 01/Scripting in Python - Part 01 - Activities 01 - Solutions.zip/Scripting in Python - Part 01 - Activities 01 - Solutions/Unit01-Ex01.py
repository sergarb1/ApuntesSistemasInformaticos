#!/bin/bash

print("Hello World from IES Serra Perenxisa!")