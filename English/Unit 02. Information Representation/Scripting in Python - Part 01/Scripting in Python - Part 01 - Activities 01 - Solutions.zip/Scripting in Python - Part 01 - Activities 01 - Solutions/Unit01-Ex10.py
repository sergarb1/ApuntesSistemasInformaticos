#!/bin/bash
print("\033[92mOK: no errors")
print("\033[93mWarning")
print("\033[41m\033[92mError")