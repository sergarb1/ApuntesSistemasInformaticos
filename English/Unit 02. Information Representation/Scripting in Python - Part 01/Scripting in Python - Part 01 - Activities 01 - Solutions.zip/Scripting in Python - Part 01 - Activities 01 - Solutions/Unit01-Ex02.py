#!/bin/bash

myName="Sergi"
print("Hello my name is Victor"+myName)