#!/bin/bash

for i in range(1,4):
    print("This is the line number "+str(i)+".")