#!/bin/bash
myNumber = int(input('Enter an integer: '))
myNumberPow2=myNumber**2
myNumberPow3=myNumber**3
print("Number: "+str(myNumber)+", Pow 2: "+str(myNumberPow2)+", Pow 3: "+str(myNumberPow3))