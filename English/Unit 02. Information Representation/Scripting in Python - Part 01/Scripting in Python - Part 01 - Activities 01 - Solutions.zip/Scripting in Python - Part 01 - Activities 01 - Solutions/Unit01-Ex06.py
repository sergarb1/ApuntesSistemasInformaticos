#!/bin/bash
print("Hi! I'm studying Python.")