#!/bin/bash

print("Introduce two numbers (temperature and humidity) separated by spaces:")
#This is an alternative way to read 2 numbers.
#It reads an string, split it using " " and map each number to int() function to convert to integer 
temperature,humidity=map(int,input().split(" "))


if(temperature<-25):
    print("Oh my god! It is the end of the world!")
elif((temperature>40) or (temperature>32 and humidity>75) or (humidity>88)):
    print("Cancel School")
else:
    print("Go to School!")