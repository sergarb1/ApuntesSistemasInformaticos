#!/bin/bash

print("Introduce three numbers separated by spaces:")
#This is an alternative way to read 3 numbers.
#It reads an string, split it using " " and map each number to int() function to convert to integer 
num1,num2,num3=map(int,input().split(" "))



if(num1==num2 and num1==num3):
    print("The three numbers are equal")
elif (num1==num2) or (num1==num3) or (num2==num3):
    print("Only two numbers are equal")
else:
    print("The three numbers are different")