#!/bin/bash
numberToGuess=22

number=0
lives=5

while number!=numberToGuess and lives>0:

    number=int(input("Write a number:"))
    lives=lives-1

    if (number!=numberToGuess):
        print("Try again, it isn't right. "+str(lives)+" oportunities left.")
        if(number<numberToGuess):
            print("Tip: the number to guess is greater")
        elif(number>numberToGuess):
            print("Tip: the number to guess is lower")

#Outside while statement
if (number==numberToGuess):
    print("Congratulations! It is right")
else:
    print("Sorry, you didn't guess the number")
