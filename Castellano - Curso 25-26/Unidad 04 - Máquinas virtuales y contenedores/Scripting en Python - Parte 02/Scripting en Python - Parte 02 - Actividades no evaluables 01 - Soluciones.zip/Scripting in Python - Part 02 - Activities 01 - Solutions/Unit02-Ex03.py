#!/bin/bash

word1=input("Write first word:")
word2=input("Write second word:")

if word1==word2:
    print("Words are equal")
else:
    print("Words are different")