#!/bin/bash

print("Introduce four numbers separated by spaces:")
#This is an alternative way to read 4 numbers.
#It reads an string, split it using " " and map each number to int() function to convert to integer 
num1,num2,num3,num4=map(int,input().split(" "))


mayor=max(num1,num2)
mayor=max(mayor,num3)
mayor=max(mayor,num4)
print("Maximum: "+str(mayor))

menor=min(num1,num2)
menor=min(menor,num3)
menor=min(menor,num4)

print("Minimum: "+str(menor))

