#!/bin/bash
myNumber1 = int(input('Enter an first integer: '))
myNumber2 = int(input('Enter an second integer: '))
print("Addition: "+str(myNumber1+myNumber2)+", Subtraction: "+str(myNumber1-myNumber2))