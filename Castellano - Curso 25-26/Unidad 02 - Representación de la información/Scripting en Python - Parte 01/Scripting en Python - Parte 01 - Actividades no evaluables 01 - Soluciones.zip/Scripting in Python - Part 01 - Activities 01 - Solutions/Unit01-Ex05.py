#!/bin/bash
print("This is the line number 1.")
print("This is the line number 2.")
print("This is the line number 3.")