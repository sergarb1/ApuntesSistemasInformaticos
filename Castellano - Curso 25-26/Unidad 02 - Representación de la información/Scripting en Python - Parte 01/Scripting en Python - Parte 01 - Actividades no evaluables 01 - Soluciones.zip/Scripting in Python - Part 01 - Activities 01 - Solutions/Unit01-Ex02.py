#!/bin/bash

myName="Sergi"
print("Hello my name is "+myName)