#!/usr/bin/python3

import math

def checkPrime(n):
    if (n==1): #1 no es primo por convencion matematica
        return False
    elif (n==2):
        return True
    elif (n%2==0): #Caso de divisibles por 2 que no son 2
        return False
    else:
        #Obtenemos la parte entera de la raiz del numero N
        #que es hasta donde necesitamos comprobar
        #Es mas optimo que limit=n, pero igual menos entendible 
        
        limit=int(math.sqrt(n))+1
        for x in range(3,limit,2):
            print(x)
            if(n % x==0):
                return False
        return True     

while (True):
    print("Write a number to check if it is prime")
    number=int(input())
    if(checkPrime(number)):
        print("It is prime")
    else:
        print("It is not prime")