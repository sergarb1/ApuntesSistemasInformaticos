#!/usr/bin/python3
import subprocess

p = subprocess.Popen("cat file.txt | cut -f 2 -d : | sort | uniq", stdout=subprocess.PIPE, shell=True)
(output, err) = p.communicate()
#output da el formato en bytes, para pasar a cadena

print (str(output.decode("utf-8")))
