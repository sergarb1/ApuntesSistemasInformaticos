#!/usr/bin/python3

#Inicialmente, answer vale cadena
answer=""

while (answer!="GOOD"):

    print("Is our forum GOOD or BAD?")
    #Leemos una linea del teclado y almacenamos en answer
    answer=input()

print("Ok :)")