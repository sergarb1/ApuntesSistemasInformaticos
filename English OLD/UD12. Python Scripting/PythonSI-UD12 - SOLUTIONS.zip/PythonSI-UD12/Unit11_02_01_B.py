#!/usr/bin/python3

import math

def factorial(n):
    if (n==1): 
        return 1
    else:
        num=1

        for i in range(2,n+1):
            num=num*i

        return num


while (True):
    print("Write a number to print its factorial")
    number=int(input())
    print(factorial(number))
    