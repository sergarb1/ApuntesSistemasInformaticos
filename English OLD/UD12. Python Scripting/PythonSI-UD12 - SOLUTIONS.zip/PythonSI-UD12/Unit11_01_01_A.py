#!/usr/bin/python3

#Importamos bibliotecas de sistema
import os, sys

#Bucle que recorre 70 elementos de uno en uno
for x in range(1,71,1):
    #Si es menor que diez, metemos 0 a la izquierda
    if x<10:
        #Creamos el directorio
        os.mkdir("0"+str(x))
    else:
        #Creamos el directorio
        os.mkdir(str(x))
