#!/usr/bin/python3

#Importamos bibliotecas de sistema
import os, sys


#Definimos las funciones auxiliares que usaremos en este programa

#Para opcion 1, comprobar si la habitacion esta disponible (limpia o no)

def checkRoomAvailable(room):
    #Si existe el directorio room o room+C
    if (os.path.isdir("./hotel/"+str(room)) or os.path.isdir("./hotel/"+str(room)+"C")):
        return True
    else:
        return False


#Para opcion 1, comprobar si la habitacion esta limpia
def checkRoomCleaned(room):
    #Si existe el directorio room+C
    if (os.path.isdir("./hotel/"+str(room)+"C")):
        return True
    else:
        return False


#COMIENZA EL MAIN

# Para la persistencia, vamos a jugar con crear, borrar directorios dentro de una carpeta hotel
# y comprobar si estan 

#Comprobamos si esta el directorio "hotel" y si no esta lo creamos
#https://stackabuse.com/python-check-if-a-file-or-directory-exists/
if (not os.path.isdir("./hotel")):
    os.mkdir("hotel")


#Establecemos la siguiente logica:
#Por ejemplo, habitacion 1. Si no esta libre, no existirá ni directorio 1 ni directorio 1C
#Si esta libre, pero no limpia, exisitira directorio 1, pero no directorio 1C
#Si esta libre y limpia, exisitira directorio 1C, pero no directorio 1


#Establecemos opcion como -1 al inicio para bucle
opcion=-1

#Repetimos mientras no sea la opcion "6 - Exit program"
while (opcion!=6):
    print ("Welcome to our Hotel! ")
    print ("1 - Check if room is available or not")
    print ("2 - Check if room is cleaned or not")
    print ("3 - Set 'not available' a room")
    print ("4 - Set 'available and not clean' a room")
    print ("5 - Set 'available and clean' a room")
    print ("6 - Exit program")
    print ("Please, select an option (1,2,3,4,5,6)")
    #Leemos una cadena y la convertimos a entero
    opcion=int(input())

    #Si es la opcion, usamos la funcion asignada para resolver su caso
    if(opcion==1):
        print("Write room to check if is available")
        r=int(input())

        if (checkRoomAvailable(r)==True):
            print("Room available")
        else:
            print("Room not available")
    elif(opcion==2):
        print("Write room to check if is available")
        r=int(input())

        if (checkRoomCleaned(r)==True):
            print("Room available")
        else:
            print("Room not available")
    elif(opcion==3):
        
        print("Write room to set not available")
        r=int(input())
        #Borramos las habitaciones
        if (os.path.isdir("./hotel/"+str(r))):
            os.rmdir("./hotel/"+str(r))
        if (os.path.isdir("./hotel/"+str(r)+"C")):
            os.rmdir("./hotel/"+str(r)+"C")
        
    elif(opcion==4):
        print("Write room to set available and not clean")
        r=int(input())
        #Borramos las habitaciones
        if (os.path.isdir("./hotel/"+str(r))):
            os.rmdir("./hotel/"+str(r))
        if (os.path.isdir("./hotel/"+str(r)+"C")):
            os.rmdir("./hotel/"+str(r)+"C")

        #Creamos la nueva
        os.mkdir("./hotel/"+str(r))


    elif(opcion==5):
        print("Write room to set available and clean")
        r=int(input())
        #Borramos las habitaciones
        if (os.path.isdir("./hotel/"+str(r))):
            os.rmdir("./hotel/"+str(r))
        if (os.path.isdir("./hotel/"+str(r)+"C")):
            os.rmdir("./hotel/"+str(r)+"C")

        #Creamos la nueva
        os.mkdir("./hotel/"+str(r)+"C")

    elif(opcion==6):
        print("Bye!!!\n\n")
    else:
        print("Wrong option!\n\n")