#!/usr/bin/python3

print("Tell us and operation (+,-,* or /)")
#Leemos la operacion en una cadena
operation=input()
print("Tell first operand")
#Leemos la operacion en una cadena
operand1=float(input())
print("Tell second operand")
#Leemos la operacion en una cadena
operand2=float(input())



#Several if and else
if(operation=="+"):
    result=operand1+operand2
    print(result)
elif(operation=="-"):
    result=operand1-operand2
    print(result)
elif(operation=="*"):
    result=operand1*operand2
    print(result)
elif(operation=="/"):
    result=operand1/operand2
    print(result)
else:
    print("Wrong operation")

