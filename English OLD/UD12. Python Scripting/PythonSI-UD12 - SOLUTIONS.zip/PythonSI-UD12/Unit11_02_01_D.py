#!/usr/bin/python3
import subprocess

print("Write user to check directorty")
user=input()

p = subprocess.Popen("grep "+str(user)+ " /etc/passwd | cut -f 6 -d :", stdout=subprocess.PIPE, shell=True)
(output, err) = p.communicate()
#output da el formato en bytes, para pasar a cadena

print (str(output.decode("utf-8")))
